# Control de revisión y publicación

## Se conserva la fuente de cada capítulo

Los archivos `01-tasas-interes.qmd` y `02-ecuaciones-valor.qmd` fueron copiados **sin editar su texto, fórmulas ni código**. El ZIP inicial es la referencia original. Esta entrega solo modifica los archivos de configuración, documentación, prefacio y funciones auxiliares.

## Correcciones técnicas

- Se añadió `R/configuracion-libro.R`, ausente en el ZIP recibido y llamado desde ambos capítulos.
- Se implementaron `tabla_comparacion()` y `tabla_resultado()` para tablas de auditoría, con precisión variable por fila o columna.
- Se sustituyeron los marcadores `USUARIO` y `NOMBRE DEL AUTOR` en configuración y enlaces.
- Se evitó incluir un `cover-image` inexistente.
- Se eliminó `freeze: auto`, porque no se aportó `_freeze` versionado y el flujo de GitHub ejecutará R.
- El workflow despliega `/_book` a `gh-pages`, sin requerir un `_publish.yml` generado por una publicación local inicial.
- La fuente integrada incorpora el capítulo 2; la edición pública se restringe al capítulo 1.

## Verificaciones pendientes

- Ejecutar Quarto y R y confirmar la compatibilidad efectiva con `tidyactuarial` (al menos 0.2.0).
- Revisar numéricamente todos los ejemplos y sus auditorías, en especial formatos de las tablas con precisión por fila.
- Verificar visualmente el diseño HTML en escritorio y móvil (fórmulas, tablas, gráficos, callouts y diagramas).
- Confirmar la publicación de GitHub Pages antes de añadir el vínculo recíproco en el sitio público del paquete.
- Revisar licencias, citas bibliográficas y permisos para materiales de terceros antes de publicar.
