# Enlace recíproco al libro desde tidyactuarial

**Aplicar únicamente después de verificar que el libro está publicado en GitHub Pages.**

En `tidyactuarial/README.md`, añada cerca de las viñetas o de la sección de aprendizaje:

```markdown
## Libro complementario

[Matemática Actuarial con R y tidyactuarial](https://julianfajardo1908.github.io/libro-tidyactuarial/) presenta el desarrollo matemático, los ejemplos y las auditorías reproducibles de las funciones del paquete. El libro se publica progresivamente por capítulos.
```

En `_pkgdown.yml`, si se desea un enlace en la barra de navegación, agregar un componente `book` y armonizarlo con el `navbar` existente tras inspeccionar la versión real de `pkgdown`. No reemplazar en bloque el menú de referencia del paquete.
